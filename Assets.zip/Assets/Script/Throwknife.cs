using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Throwknife : MonoBehaviour
{
    Rigidbody2D rigid;
    Vector2 force;
    bool right;

    private void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
    }

    private void Start()
    {
        rigid.AddForce(force, ForceMode2D.Impulse);
    }

    void Update()
    {
        transform.Rotate(new Vector3(0,0, right == true? -360f : 360f) * Time.deltaTime);
    }

    public void GetThrowInfor(Vector2 _force , bool _isRight)
    {
        force = _force;
        right = _isRight;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
    }
}
