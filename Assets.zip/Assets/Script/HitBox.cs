using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitBox : MonoBehaviour
{
    public enum ehitboxType
    {
        AttackBox,
        TakeAttackBox,
        TrapBox,
    }
    [SerializeField] ehitboxType hitboxType;


    [SerializeField] bool Player;
    [SerializeField] bool Monster;

     Monster monster;
     MovePlayer movePlayer;


    private void Awake()
    {
        monster = GetComponentInParent<Monster>();
        movePlayer = GetComponentInParent<MovePlayer>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (Player)
        {
            movePlayer.Player_TriggerEnter(hitboxType, collision);
        }
        else if (Monster)
        {
            monster.Monster_TriggerEnter(hitboxType, collision);
        }
        else
        {
            return;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (Player)
        {
            movePlayer.Player_TriggerExit(hitboxType, collision);
        }
        else
        {
            return;
        }
    }





}
