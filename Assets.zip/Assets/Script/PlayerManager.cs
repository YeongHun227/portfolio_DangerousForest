using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    public static PlayerManager instance;
    [SerializeField] float Player_lv;
    [SerializeField] float Player_xpMax;
    float Player_xpNow;
    [SerializeField] float Player_gold;
    [SerializeField] float Player_power;
    [SerializeField] float Player_hp;
    [SerializeField] float Player_luck;

    private void Awake()
    {
        if(instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        Player_LvUp();
    }

    public float Plaeyr_UiXP()
    {
        float uixp = 1 - Player_xpNow / Player_xpMax;
        return uixp;
    }

     private void Player_LvUp()
    {
        if ( Player_xpNow >= Player_xpMax)
        {
            Player_lv++;
            Player_xpNow -= Player_xpMax;
            Player_xpMax += 100;
        }
    }

    public void MonsterDrop(float _xp, float _gold)
    {
        Player_gold += _gold * ( 1 + (Player_luck / 10));
        Player_xpNow += _xp * ( 1 + (Player_luck / 10));
    }


}
