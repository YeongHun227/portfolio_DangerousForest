using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class UIManager : MonoBehaviour
{
    [SerializeField] GameObject viewInfor;
    [SerializeField] GameObject fabEquipment;
    bool IsOpen;

    void Start()
    {
        
    }

    private void Update()
    {
        OpenInforGUI();
    }

    public void OpenInforGUI()
    {
        if (Input.GetKeyDown(KeyCode.I) && IsOpen == false)
        {
            IsOpen = true;
            viewInfor.SetActive(true);
        }
        else if(Input.GetKeyDown(KeyCode.I) && IsOpen == true)
        {
            IsOpen = false;
            viewInfor.SetActive(false);
        }
    }
}
