using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Unity.VisualScripting.FullSerializer;
using UnityEditor;
using UnityEngine;

public class Monster : MonoBehaviour
{
    Rigidbody2D rigid;
    BoxCollider2D checkturn;
    Animator anim;
    Renderer renderer;
    Vector2 moveDir = new Vector2 (-1, 0);
    bool IsAttack;

    [Header("���� ����")]
    [SerializeField] float Monster_MaxHp; // ���� �ִ� ü��
    float Monster_NowHp; // ���� ���� ü��
    [SerializeField] float Monster_MoveSpeed; // ���� �̵��ӵ�
    [SerializeField] float Monster_Damage; // ���� ������
    [SerializeField] float Monster_Attack_Cooltime = 1; // ���� ���ݼӵ�
    float Monster_Attack_Timer; // ���� ���ݼӵ� Ÿ�̸�
    float Monster_HitTiemr;
    float Monster_Hit_Time = 0.1f;


    [Header("���� ��ô")]
    [SerializeField] bool Monster_Ranger = false; // ���� ���Ÿ� ���� Ȱ��ȭ
    [SerializeField] float Monster_AtkRange;
    [SerializeField] GameObject PrefabThrow;
    [SerializeField] Vector3 throwForce = new Vector2(5f,0f);

    private void Awake()
    {
        Monster_NowHp = Monster_MaxHp;
        rigid = GetComponent<Rigidbody2D>();
        checkturn = GetComponent<BoxCollider2D>();
        anim = GetComponent<Animator>();
        renderer = GetComponent<Renderer>();
    }

    void Update()
    {
        Monster_RangerAttack();
        Monster_Move();
        Monster_Timer();
        Monster_doani();
    }

    public void Monster_TriggerEnter(HitBox.ehitboxType _type, Collider2D _collision)
    {

        if (_type == HitBox.ehitboxType.AttackBox) // �÷��̾� ���� ������ Ȯ��
        {
            if (_collision.gameObject.layer == LayerMask.NameToLayer("Attack"))
            {
                renderer.material.color = Color.red;
                Monster_HitTiemr = Monster_Hit_Time;
                Monster_NowHp -= _collision.gameObject.GetComponentInParent<MovePlayer>().Player_SendDamage();
                Monster_dieCheck();
            }
        }

    }

    private void Monster_dieCheck()
    {
        if (Monster_NowHp <= 0)
        {
            Monster_Drop();
            anim.SetTrigger("Die");
        }
    }

    private void Monster_Drop()
    {

    }

    public void Monster_Die()
    {
        Destroy(gameObject);
    }

    private void Monster_Timer() // ���� ���� Ÿ�̸�
    {
        if(Monster_Attack_Timer > 0)
        {
            Monster_Attack_Timer -= Time.deltaTime;
            if(Monster_Attack_Timer < 0)
            {
                Monster_Attack_Timer = 0;
                IsAttack = false;
            }
        }

        if(Monster_HitTiemr > 0)
        {
            Monster_HitTiemr -= Time.deltaTime;
            if (Monster_HitTiemr < 0)
            {
                Monster_HitTiemr = 0;
                renderer.material.color = Color.white;
            }
        }

    }

    private void Monster_Move() // ���� �̵� + �� + ����
    {
        if (IsAttack == true)
        {
            return;
        }
        else if (checkturn.IsTouchingLayers(LayerMask.GetMask("Player")) == true && Monster_Ranger == false)
        {
            Monster_AttackMt();
            return;
        }
        else if (checkturn.IsTouchingLayers(LayerMask.GetMask("Wall")) == true ||
                (checkturn.IsTouchingLayers(LayerMask.GetMask("Ground")) == false))
        {
            if (transform.localScale.x < 0 && moveDir.x < 0)
            {
                Vector3 scale = transform.localScale;
                scale.x = 1;
                transform.localScale = scale;
                moveDir.x = 1;

            }
            else if (transform.localScale.x > 0 && moveDir.x > 0)
            {
                Vector3 scale = transform.localScale;
                scale.x = -1;
                transform.localScale = scale;
                moveDir.x = -1;
            }
        }
        rigid.velocity = new Vector2(moveDir.x * Monster_MoveSpeed, rigid.velocity.y);
    }

    private void Monster_AttackMt() // ���� ���ݸ��
    {
        if (Monster_Attack_Timer == 0)
        {
            IsAttack = true;
            anim.SetTrigger("AttackToPlayer");
            Monster_Attack_Timer = Monster_Attack_Cooltime;
        }
    }

    private void Monster_doani() // ���� ���ϸ��̼�
    {
        anim.SetBool("IsAttack", IsAttack);
    }

    public float Monster_SendDamage()
    {
        float damage = Monster_Damage;
        return damage;
    }

    private void Monster_RangerAttack()
    {
        if (Monster_Ranger)
        {
            RaycastHit2D CheckPlayer = Physics2D.Raycast(transform.position,
            new Vector2(transform.localScale.x > 0 ? 1 : -1 , 0), Monster_AtkRange, LayerMask.GetMask("Player"));
            if (CheckPlayer == true)
            {
                Monster_AttackMt();
            }
        }

    }
    public void Monster_RangerCreate()
    {
        GameObject go = Instantiate(PrefabThrow, transform.position , Quaternion.identity , transform.root);
        Throwknife goSc = go.GetComponent<Throwknife>();
        bool isRight = transform.localScale.x < 0 ? true : false;
        Vector2 fixedThrowForce = throwForce;
        if(isRight == true)
        {
            fixedThrowForce = -throwForce;
        }
        goSc.GetThrowInfor(fixedThrowForce, isRight);
        Destroy(go, 2f);
    }

    

}
